from setuptools import setup

with open("README.md", "r") as arq:
    readme = arq.read()

setup(name='ptsip',
    version='0.0.1',
    license='MIT License',
    author='eliel lima silva',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='eliellimasilva2019@gmail.com',
    keywords='ptsip',
    description=u'fins de teste',
    packages=['ptsip'],
    install_requires=[''],)