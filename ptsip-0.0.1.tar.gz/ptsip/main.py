import os 
internal = os.getcwd()
def printPackages():
    filesInPath = []
    path = os.path.join(internal, "packages/")
    for root, dirs, files in os.walk(path):
        for file in files:
            way = os.path.join(root, file)
            if os.path.exists(way):
                filesInPath.append(way)
                print(way)
    print(filesInPath)
    
def pathexists():
    if os.path.exists(internal):
        print(True)
    else:
        print(False)